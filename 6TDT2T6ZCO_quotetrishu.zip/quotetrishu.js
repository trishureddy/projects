const quotes = [
    "Code is like humor. When you have to explain it, it’s bad.",
    "Experience is the name everyone gives to their mistakes.",
    "First, solve the problem. Then, write the code.",
    "In order to be irreplaceable, one must always be different.",
    "JavaScript is the duct tape of the internet."
];

const quoteElement = document.getElementById("quote");
const newQuoteBtn = document.getElementById("newQuote");

newQuoteBtn.addEventListener("click", () => {
    const randomIndex = Math.floor(Math.random() * quotes.length);
    quoteElement.textContent = quotes[randomIndex];
});