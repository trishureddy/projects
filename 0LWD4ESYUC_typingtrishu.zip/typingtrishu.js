const quotes = [
    "JavaScript is the language of the web.",
    "Typing speed matters when coding.",
    "Practice makes perfect.",
    "Code more, worry less.",
    "Keep calm and code on."
];

const quoteElement = document.getElementById("quote");
const input = document.getElementById("input");
const startBtn = document.getElementById("startBtn");
const result = document.getElementById("result");

let startTime;
let currentQuote = "";

startBtn.addEventListener("click", () => {
    currentQuote = quotes[Math.floor(Math.random() * quotes.length)];
    quoteElement.textContent = currentQuote;
    input.value = "";
    input.disabled = false;
    input.focus();
    result.textContent = "";
    startTime = new Date().getTime();
});

input.addEventListener("input", () => {
    if (input.value === currentQuote) {
        const endTime = new Date().getTime();
        const timeTaken = (endTime - startTime) / 1000;
        const wordCount = currentQuote.split(" ").length;
        const wpm = Math.round((wordCount / timeTaken) * 60);
        result.textContent = `🎉 Done! Time: ${timeTaken.toFixed(2)}s | WPM: ${wpm}`;
        input.disabled = true;
    }
});