
//===========================================================================================================
// CODE - VERSION 06

App = {
  web3Provider: null,
  contracts: {},
  account: '0x0',

  init: function() {
    return App.initWeb3();
  },

  initWeb3: function() {
    if (window.ethereum) {
      App.web3Provider = window.ethereum;
      try {
        window.ethereum.enable();
      } catch (error) {
        console.error("User denied account access");
      }
    } else if (window.web3) {
      App.web3Provider = window.web3.currentProvider;
    } else {
      App.web3Provider = new Web3.providers.HttpProvider('http://localhost:7545');
    }
    web3 = new Web3(App.web3Provider);

    return App.initContract();
  },

  initContract: function() {
    $.getJSON("Election.json", function(election) {
      App.contracts.Election = TruffleContract(election);
      App.contracts.Election.setProvider(App.web3Provider);

      return App.render();
    });
  },

  render: function() {
    var electionInstance;
    var loader = $("#loader");
    var content = $("#content");

    // Light color gradient background
    $("body").css({
      "background": "linear-gradient(135deg, #cfe2f3 0%, #D7E3D1 100%)",
      "min-height": "100vh",
      "display": "flex",
      "align-items": "center",
      "justify-content": "center",
      "font-family": "Arial, sans-serif",
      "color": "#333"
    });

    // Styling for loader
    loader.css({
      "text-align": "center",
      "padding": "20px",
      "background": "rgba(255, 255, 255, 0.1)",
      "border-radius": "10px",
      "color": "#fff",
      "font-size": "18px"
    });

    // Enhanced content styling
    content.css({
      "background-color": "rgba(255, 255, 255, 0.9)",
      "padding": "30px",
      "border-radius": "12px",
      "box-shadow": "0 8px 20px rgba(0, 0, 0, 0.2)",
      "width": "100%",
      "max-width": "700px",
      "text-align": "center"
    });
// List of random user details
const randomDetails = [
  { name: "Narendra Modi", fatherName: "Damodardas Modi", gender: "Male", dob: "17-09-1950" },
  { name: "Sonia Gandhi", fatherName: "Stefano Maino", gender: "Female", dob: "09-12-1946" },
  { name: "Arvind Kejriwal", fatherName: "Govind Ram Kejriwal", gender: "Male", dob: "16-08-1968" },
  { name: "Mamata Banerjee", fatherName: "Promileswar Banerjee", gender: "Female", dob: "05-01-1955" },
  { name: "Rahul Gandhi", fatherName: "Rajiv Gandhi", gender: "Male", dob: "19-06-1970" }
];



// Function to set random details on the card
function setRandomDetails() {
  const randomDetail = randomDetails[Math.floor(Math.random() * randomDetails.length)];
  $("#voterName").text(randomDetail.name);
  $("#fatherName").text(randomDetail.fatherName);
  $("#gender").text(randomDetail.gender);
  $("#dob").text(randomDetail.dob);
}

// Add a voter ID card in the top-left corner with adjusted positioning and styling
if ($("#voterCard").length === 0) {
  $("body").append(`
    <div id="voterCard" style="
      position: fixed;
      top: 60px; /* Adjusted distance from the top */
      left: 20px;
      width: 220px;
      background-color: #e3f2fd;
      border: 1px solid #90caf9;
      border-radius: 10px;
      box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
      padding: 15px;
      color: #333;
      font-family: Arial, sans-serif;
    ">
      <h4 style="text-align: center; color: #0d47a1;">Election Commission of India</h4>
      <div style="text-align: center; margin-bottom: 10px;">
        <img src="profile.png" alt="User Image" style="width: 60px; height: 60px; border-radius: 50%; box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);">
      </div>
      <p><strong>Voter ID:</strong> <span id="accountID" style="display: inline-block; width: 100%; white-space: nowrap; overflow: hidden; text-overflow: ellipsis;"></span></p>
      <p><strong>Name:</strong> <span id="voterName">John Doe</span></p>
      <p><strong>Father's Name:</strong> <span id="fatherName">Richard Doe</span></p>
      <p><strong>Gender:</strong> <span id="gender">Male</span></p>
      <p><strong>DOB:</strong> <span id="dob">01-01-1990</span></p>
    </div>
  `);
}

// After initializing the account, update the accountID in the voter card and set random details
web3.eth.getCoinbase(function(err, account) {
  if (err === null) {
    App.account = account;
    $("#accountAddress").html(`Your Account: ${account}`).css({
      "font-weight": "bold",
      "color": "#333",
      "background-color": "#e0f7fa",
      "padding": "10px 20px",
      "border-radius": "12px",
      "margin-bottom": "20px",
      "text-align": "center",
      "display": "inline-block"
    });

    // Set the account ID on the voter card with ellipsis if too long
    $("#accountID").text(account);

    // Update with random details each time the account ID is set
    setRandomDetails();
  }
});
    // Fetch the user's Ethereum account and update user card
    web3.eth.getCoinbase(function(err, account) {
      if (err === null) {
        App.account = account;
        $("#accountAddress").html(`Your Account: ${account}`).css({
          "font-weight": "bold",
          "color": "#333",
          "background-color": "#e0f7fa",
          "padding": "10px 20px",
          "border-radius": "12px",
          "margin-bottom": "20px",
          "text-align": "center",
          "display": "inline-block"
        });
        $("#userName").text("Name: John Doe"); // Update with user's name
        $("#userId").text(`ID: ${account}`);
      }
    });

    // application card
    App.contracts.Election.deployed().then(function(instance) {
      electionInstance = instance;
      return electionInstance.candidatesCount();
    }).then(function(candidatesCount) {
      var candidatesResults = $("#candidatesResults");
      candidatesResults.empty();

      let maxVoteCount = 0;
      let winner = null;

      for (var i = 1; i <= candidatesCount; i++) {
        electionInstance.candidates(i).then(function(candidate) {
          var id = candidate[0];
          var name = candidate[1];
          var voteCount = candidate[2];

          if (voteCount > maxVoteCount) {
            maxVoteCount = voteCount;
            winner = name;
          }

          var candidateTemplate = `
            <tr style="border-bottom: 1px solid #ddd;">
              <th style="color: #007bff; font-size: 1.1em; padding: 8px 12px;">${id}</th>
              <td style="padding: 8px 12px; color: #333;">${name}</td>
              <td style="padding: 8px 12px; color: #666;">${voteCount}</td>
              <td><button class='btn btn-primary' onclick='App.castVote(${id})' style='background-color: #28a745; border-color: #28a745; padding: 8px 16px; font-size: 0.9em; border-radius: 8px;'>Vote</button></td>
            </tr>`;
          candidatesResults.append(candidateTemplate);
        });
      }

      $("#declareWinnerButton").click(function() {
        if (winner) {
          $("#winner").html(`Winner: ${winner} with ${maxVoteCount} votes`).css({
            "color": "#28a745",
            "font-weight": "bold",
            "font-size": "1.2em",
            "margin-top": "20px"
          });
        }
      });

      loader.hide();
      content.show();
    }).catch(function(error) {
      console.warn(error);
    });
  },

  castVote: function(candidateId) {
    App.contracts.Election.deployed().then(function(instance) {
      return instance.vote(candidateId, { from: App.account });
    }).then(function(result) {
      console.log("Vote cast successfully!");
      App.listenForEvents();
      App.render();
    }).catch(function(err) {
      console.error(err);
    });
  },

  listenForEvents: function() {
    App.contracts.Election.deployed().then(function(instance) {
      instance.votedEvent({}, {
        fromBlock: 0,
        toBlock: 'latest'
      }).watch(function(error, event) {
        if (!error) {
          console.log("Event triggered", event);
          App.render();
        } else {
          console.error(error);
        }
      });
    });
  }
};

$(function() {
  $(window).load(function() {
    App.init();
  });
});

// Enhanced Declare Winner button styling
$(document).ready(function() {
  $("#content").append(`
    <div style="margin-top: 30px; text-align: center;">
      <button id="declareWinnerButton" class="btn btn-success" style="padding: 12px 24px; font-size: 1em; background-color: #007bff; border-color: #007bff; border-radius: 10px; color: white;">Declare Winner</button>
      <p id="winner" style="padding-top: 10px; font-size: 1.1em;"></p>
    </div>
  `);
});


// OPTIMISTIC ROLLUPS
const ethers = require('ethers');

// Sending batched transactions to the rollup smart contract
async function submitBatch(transactions) {
    const provider = new ethers.providers.JsonRpcProvider('<RPC_ENDPOINT>');
    const signer = new ethers.Wallet('<PRIVATE_KEY>', provider);

    const rollupContract = new ethers.Contract('<ROLLUP_CONTRACT_ADDRESS>', ABI, signer);

    try {
        const tx = await rollupContract.submitBatch(transactions);
        console.log(`Batch submitted: ${tx.hash}`);
    } catch (error) {
        console.error('Error submitting batch:', error);
    }
}























// App = {
//   web3Provider: null,
//   contracts: {},
//   account: '0x0',

//   init: function() {
//     return App.initWeb3();
//   },

//   initWeb3: function() {
//     if (window.ethereum) {
//       App.web3Provider = window.ethereum;
//       try {
//         window.ethereum.enable();
//       } catch (error) {
//         console.error("User denied account access");
//       }
//     } else if (window.web3) {
//       App.web3Provider = window.web3.currentProvider;
//     } else {
//       App.web3Provider = new Web3.providers.HttpProvider('http://localhost:7545');
//     }
//     web3 = new Web3(App.web3Provider);

//     return App.initContract();
//   },

//   initContract: function() {
//     $.getJSON("Election.json", function(election) {
//       App.contracts.Election = TruffleContract(election);
//       App.contracts.Election.setProvider(App.web3Provider);

//       return App.render();
//     });
//   },

//   render: function() {
//     var electionInstance;
//     var loader = $("#loader");
//     var content = $("#content");

//     loader.show();
//     content.hide();

//     web3.eth.getCoinbase(function(err, account) {
//       if (err === null) {
//         App.account = account;
//         $("#accountAddress").html("Your Account: " + account);
//       }
//     });

//     App.contracts.Election.deployed().then(function(instance) {
//       electionInstance = instance;
//       return electionInstance.candidatesCount();
//     }).then(function(candidatesCount) {
//       var candidatesResults = $("#candidatesResults");
//       candidatesResults.empty();

//       for (var i = 1; i <= candidatesCount; i++) {
//         electionInstance.candidates(i).then(function(candidate) {
//           var id = candidate[0];
//           var name = candidate[1];
//           var voteCount = candidate[2];

//           var candidateTemplate = "<tr><th>" + id + "</th><td>" + name + "</td><td>" + voteCount + "</td>" +
//                                   "<td><button class='btn btn-primary' onclick='App.castVote(" + id + ")'>Vote</button></td></tr>"
//           candidatesResults.append(candidateTemplate);
//         });
//       }

//       loader.hide();
//       content.show();
//     }).catch(function(error) {
//       console.warn(error);
//     });
//   },

//   castVote: function(candidateId) {
//     App.contracts.Election.deployed().then(function(instance) {
//       return instance.vote(candidateId, { from: App.account });
//     }).then(function(result) {
//       console.log("Vote cast successfully!");
//       // Listen for the voted event
//       App.listenForEvents();
//       App.render();
//     }).catch(function(err) {
//       console.error(err);
//     });
//   },

//   listenForEvents: function() {
//     App.contracts.Election.deployed().then(function(instance) {
//       instance.votedEvent({}, {
//         fromBlock: 0,
//         toBlock: 'latest'
//       }).watch(function(error, event) {
//         if (!error) {
//           console.log("Event triggered", event);
//           App.render();
//         } else {
//           console.error(error);
//         }
//       });
//     });
//   }
// };

// $(function() {
//   $(window).load(function() {
//     App.init();
//   });
// });


// // -----------------------------
// class OptimisticRollup {
//   constructor() {
//       this.voteBatch = [];
//       this.batchSize = 5; 
//   }

  
//   castVote(vote) {
//       this.voteBatch.push(vote);
//       // console.log(`Vote cast: ${vote}`);
      
//       //size check
//       if (this.voteBatch.length >= this.batchSize) {
//           this.commitVotes();
//       }
//   }

//   // Method to commit the votes to the main blockchain
//   commitVotes() {
//       // console.log("Committing votes to the blockchain...");
      
//       this.sendToBlockchain(this.voteBatch);
      
//       // Clear the batch after committing
//       this.voteBatch = [];
//   }

  
//   sendToBlockchain(votes) {
//       // Simulate a network request to a blockchain
//       // console.log(`Sending the following votes to the blockchain: ${votes.join(', ')}`);
      
//       // Simulate success response from the blockchain
//       setTimeout(() => {
//           console.log("Votes successfully committed!");
//       }, 1000); // Simulate network delay
//   }
// }

// ==============================================================================================

//  CODE - VERSION 02



// App = {
//   web3Provider: null,
//   contracts: {},
//   account: '0x0',

//   init: function() {
//     return App.initWeb3();
//   },

//   initWeb3: function() {
//     if (window.ethereum) {
//       App.web3Provider = window.ethereum;
//       try {
//         window.ethereum.enable();
//       } catch (error) {
//         console.error("User denied account access");
//       }
//     } else if (window.web3) {
//       App.web3Provider = window.web3.currentProvider;
//     } else {
//       App.web3Provider = new Web3.providers.HttpProvider('http://localhost:7545');
//     }
//     web3 = new Web3(App.web3Provider);

//     return App.initContract();
//   },

//   initContract: function() {
//     $.getJSON("Election.json", function(election) {
//       App.contracts.Election = TruffleContract(election);
//       App.contracts.Election.setProvider(App.web3Provider);

//       return App.render();
//     });
//   },

//   render: function() {
//     var electionInstance;
//     var loader = $("#loader");
//     var content = $("#content");

//     // Add inline styles
//     loader.css({
//       "text-align": "center",
//       "padding": "20px",
//       "background": "url('loader-background.jpg') center/cover no-repeat", // Add your image path here
//       "color": "white",
//       "font-size": "18px"
//     });

//     content.css({
//       "background-color": "#f7f7f9",
//       "padding": "20px",
//       "border-radius": "8px",
//       "box-shadow": "0 4px 8px rgba(0, 0, 0, 0.1)"
//     });

//     loader.show();
//     content.hide();

//     web3.eth.getCoinbase(function(err, account) {
//       if (err === null) {
//         App.account = account;
//         $("#accountAddress").html("Your Account: " + account).css({
//           "font-weight": "bold",
//           "color": "#007bff",
//           "margin-bottom": "20px",
//         });
//       }
//     });

//     App.contracts.Election.deployed().then(function(instance) {
//       electionInstance = instance;
//       return electionInstance.candidatesCount();
//     }).then(function(candidatesCount) {
//       var candidatesResults = $("#candidatesResults");
//       candidatesResults.empty();

//       for (var i = 1; i <= candidatesCount; i++) {
//         electionInstance.candidates(i).then(function(candidate) {
//           var id = candidate[0];
//           var name = candidate[1];
//           var voteCount = candidate[2];

//           var candidateTemplate = `
//             <tr>
//               <th style="color: #007bff;">${id}</th>
//               <td>${name}</td>
//               <td>${voteCount}</td>
//               <td><button class='btn btn-primary' onclick='App.castVote(${id})' style='background-color: #28a745; border-color: #28a745;'>Vote</button></td>
//             </tr>`;
//           candidatesResults.append(candidateTemplate);
//         });
//       }

//       loader.hide();
//       content.show();
//     }).catch(function(error) {
//       console.warn(error);
//     });
//   },

//   castVote: function(candidateId) {
//     App.contracts.Election.deployed().then(function(instance) {
//       return instance.vote(candidateId, { from: App.account });
//     }).then(function(result) {
//       console.log("Vote cast successfully!");
//       App.listenForEvents();
//       App.render();
//     }).catch(function(err) {
//       console.error(err);
//     });
//   },

//   listenForEvents: function() {
//     App.contracts.Election.deployed().then(function(instance) {
//       instance.votedEvent({}, {
//         fromBlock: 0,
//         toBlock: 'latest'
//       }).watch(function(error, event) {
//         if (!error) {
//           console.log("Event triggered", event);
//           App.render();
//         } else {
//           console.error(error);
//         }
//       });
//     });
//   }
// };

// $(function() {
//   $(window).load(function() {
//     App.init();
//   });
// });

// // OptimisticRollup class remains the same
// class OptimisticRollup {
//   constructor() {
//       this.voteBatch = [];
//       this.batchSize = 5; 
//   }

//   castVote(vote) {
//       this.voteBatch.push(vote);
//       if (this.voteBatch.length >= this.batchSize) {
//           this.commitVotes();
//       }
//   }

//   commitVotes() {
//       this.sendToBlockchain(this.voteBatch);
//       this.voteBatch = [];
//   }

//   sendToBlockchain(votes) {
//       setTimeout(() => {
//           console.log("Votes successfully committed!");
//       }, 1000); // Simulate network delay
//   }
// }



// ========================================================================================================
// CODE - VERSION 03


// App = {
//   web3Provider: null,
//   contracts: {},
//   account: '0x0',

//   init: function() {
//     return App.initWeb3();
//   },

//   initWeb3: function() {
//     if (window.ethereum) {
//       App.web3Provider = window.ethereum;
//       try {
//         window.ethereum.enable();
//       } catch (error) {
//         console.error("User denied account access");
//       }
//     } else if (window.web3) {
//       App.web3Provider = window.web3.currentProvider;
//     } else {
//       App.web3Provider = new Web3.providers.HttpProvider('http://localhost:7545');
//     }
//     web3 = new Web3(App.web3Provider);

//     return App.initContract();
//   },

//   initContract: function() {
//     $.getJSON("Election.json", function(election) {
//       App.contracts.Election = TruffleContract(election);
//       App.contracts.Election.setProvider(App.web3Provider);

//       return App.render();
//     });
//   },

//   render: function() {
//     var electionInstance;
//     var loader = $("#loader");
//     var content = $("#content");

//     // Styling for loader and content
//     loader.css({
//       "text-align": "center",
//       "padding": "20px",
//       "background": "url('loader-background.jpg') center/cover no-repeat",
//       "color": "white",
//       "font-size": "18px"
//     });

//     content.css({
//       "background-color": "#f7f7f9",
//       "padding": "20px",
//       "border-radius": "8px",
//       "box-shadow": "0 4px 8px rgba(0, 0, 0, 0.1)"
//     });

//     loader.show();
//     content.hide();

//     web3.eth.getCoinbase(function(err, account) {
//       if (err === null) {
//         App.account = account;
//         $("#accountAddress").html("Your Account: " + account).css({
//           "font-weight": "bold",
//           "color": "#007bff",
//           "margin-bottom": "20px"
//         });
//       }
//     });

//     App.contracts.Election.deployed().then(function(instance) {
//       electionInstance = instance;
//       return electionInstance.candidatesCount();
//     }).then(function(candidatesCount) {
//       var candidatesResults = $("#candidatesResults");
//       candidatesResults.empty();

//       let maxVoteCount = 0;
//       let winner = null;

//       for (var i = 1; i <= candidatesCount; i++) {
//         electionInstance.candidates(i).then(function(candidate) {
//           var id = candidate[0];
//           var name = candidate[1];
//           var voteCount = candidate[2];

//           // Update maxVoteCount and winner if this candidate has more votes
//           if (voteCount > maxVoteCount) {
//             maxVoteCount = voteCount;
//             winner = name;
//           }

//           var candidateTemplate = `
//             <tr>
//               <th style="color: #007bff;">${id}</th>
//               <td>${name}</td>
//               <td>${voteCount}</td>
//               <td><button class='btn btn-primary' onclick='App.castVote(${id})' style='background-color: #28a745; border-color: #28a745;'>Vote</button></td>
//             </tr>`;
//           candidatesResults.append(candidateTemplate);
//         });
//       }

//       // Show winner on button click
//       $("#declareWinnerButton").click(function() {
//         if (winner) {
//           $("#winner").html(`Winner: ${winner} with ${maxVoteCount} votes`).css({
//             "color": "#28a745",
//             "font-weight": "bold",
//             "font-size": "18px",
//             "margin-top": "20px"
//           });
//         }
//       });

//       loader.hide();
//       content.show();
//     }).catch(function(error) {
//       console.warn(error);
//     });
//   },

//   castVote: function(candidateId) {
//     App.contracts.Election.deployed().then(function(instance) {
//       return instance.vote(candidateId, { from: App.account });
//     }).then(function(result) {
//       console.log("Vote cast successfully!");
//       App.listenForEvents();
//       App.render();
//     }).catch(function(err) {
//       console.error(err);
//     });
//   },

//   listenForEvents: function() {
//     App.contracts.Election.deployed().then(function(instance) {
//       instance.votedEvent({}, {
//         fromBlock: 0,
//         toBlock: 'latest'
//       }).watch(function(error, event) {
//         if (!error) {
//           console.log("Event triggered", event);
//           App.render();
//         } else {
//           console.error(error);
//         }
//       });
//     });
//   }
// };

// $(function() {
//   $(window).load(function() {
//     App.init();
//   });
// });

// // Add button for declaring the winner
// $(document).ready(function() {
//   $("#content").append(`
//     <div style="margin-top: 30px;">
//       <button id="declareWinnerButton" class="btn btn-success" style="padding: 10px 20px; font-size: 16px; background-color: #007bff; border-color: #007bff;">Declare Winner</button>
//       <p id="winner" style="text-align: center;"></p>
//     </div>
//   `);
// });



//===========================================================================================================
// CODE - VERSION 04


// App = {
//   web3Provider: null,
//   contracts: {},
//   account: '0x0',

//   init: function() {
//     return App.initWeb3();
//   },

//   initWeb3: function() {
//     if (window.ethereum) {
//       App.web3Provider = window.ethereum;
//       try {
//         window.ethereum.enable();
//       } catch (error) {
//         console.error("User denied account access");
//       }
//     } else if (window.web3) {
//       App.web3Provider = window.web3.currentProvider;
//     } else {
//       App.web3Provider = new Web3.providers.HttpProvider('http://localhost:7545');
//     }
//     web3 = new Web3(App.web3Provider);

//     return App.initContract();
//   },

//   initContract: function() {
//     $.getJSON("Election.json", function(election) {
//       App.contracts.Election = TruffleContract(election);
//       App.contracts.Election.setProvider(App.web3Provider);

//       return App.render();
//     });
//   },

//   render: function() {
//     var electionInstance;
//     var loader = $("#loader");
//     var content = $("#content");

//     // Style for loader
//     loader.css({
//       "text-align": "center",
//       "padding": "20px",
//       "background": "url('loader-background.jpg') center/cover no-repeat",
//       "color": "white",
//       "font-size": "18px"
//     });

//     // Style for main content
//     content.css({
//       "background-color": "#ffffff",
//       "padding": "30px",
//       "border-radius": "12px",
//       "box-shadow": "0 4px 10px rgba(0, 0, 0, 0.2)"
//     });

//     loader.show();
//     content.hide();

//     web3.eth.getCoinbase(function(err, account) {
//       if (err === null) {
//         App.account = account;
//         $("#accountAddress").html(`Your Account: ${account}`).css({
//           "font-weight": "bold",
//           "color": "#333",
//           "background-color": "#f0f0f0",
//           "padding": "10px",
//           "border-radius": "8px",
//           "margin-bottom": "20px",
//           "text-align": "center"
//         });
//       }
//     });

//     App.contracts.Election.deployed().then(function(instance) {
//       electionInstance = instance;
//       return electionInstance.candidatesCount();
//     }).then(function(candidatesCount) {
//       var candidatesResults = $("#candidatesResults");
//       candidatesResults.empty();

//       let maxVoteCount = 0;
//       let winner = null;

//       for (var i = 1; i <= candidatesCount; i++) {
//         electionInstance.candidates(i).then(function(candidate) {
//           var id = candidate[0];
//           var name = candidate[1];
//           var voteCount = candidate[2];

//           if (voteCount > maxVoteCount) {
//             maxVoteCount = voteCount;
//             winner = name;
//           }

//           var candidateTemplate = `
//             <tr style="border-bottom: 1px solid #e0e0e0;">
//               <th style="color: #007bff; font-size: 1.1em;">${id}</th>
//               <td style="padding: 10px; color: #333;">${name}</td>
//               <td style="padding: 10px; color: #666;">${voteCount}</td>
//               <td><button class='btn btn-primary' onclick='App.castVote(${id})' style='background-color: #28a745; border-color: #28a745; padding: 5px 12px; font-size: 0.9em; border-radius: 8px;'>Vote</button></td>
//             </tr>`;
//           candidatesResults.append(candidateTemplate);
//         });
//       }

//       $("#declareWinnerButton").click(function() {
//         if (winner) {
//           $("#winner").html(`Elected Candidate: ${winner} with ${maxVoteCount} votes`).css({
//             "color": "#28a745",
//             "font-weight": "bold",
//             "font-size": "1.2em",
//             "margin-top": "20px",
//             "text-align": "center"
//           });
//         }
//       });

//       loader.hide();
//       content.show();
//     }).catch(function(error) {
//       console.warn(error);
//     });
//   },

//   castVote: function(candidateId) {
//     App.contracts.Election.deployed().then(function(instance) {
//       return instance.vote(candidateId, { from: App.account });
//     }).then(function(result) {
//       console.log("Vote cast successfully!");
//       App.listenForEvents();
//       App.render();
//     }).catch(function(err) {
//       console.error(err);
//     });
//   },

//   listenForEvents: function() {
//     App.contracts.Election.deployed().then(function(instance) {
//       instance.votedEvent({}, {
//         fromBlock: 0,
//         toBlock: 'latest'
//       }).watch(function(error, event) {
//         if (!error) {
//           console.log("Event triggered", event);
//           App.render();
//         } else {
//           console.error(error);
//         }
//       });
//     });
//   }
// };

// $(function() {
//   $(window).load(function() {
//     App.init();
//   });
// });

// // Adding Declare Winner button and its styling
// $(document).ready(function() {
//   $("#content").append(`
//     <div style="margin-top: 30px; text-align: center;">
//       <button id="declareWinnerButton" class="btn btn-success" style="padding: 12px 24px; font-size: 1em; background-color: #007bff; border-color: #007bff; border-radius: 10px;">Declare Result</button>
//       <p id="winner" style="text-align: center; padding-top: 10px;"></p>
//     </div>
//   `);
// });



//===========================================================================================================
// CODE - VERSION 05


// App = {
//   web3Provider: null,
//   contracts: {},
//   account: '0x0',

//   init: function() {
//     return App.initWeb3();
//   },

//   initWeb3: function() {
//     if (window.ethereum) {
//       App.web3Provider = window.ethereum;
//       try {
//         window.ethereum.enable();
//       } catch (error) {
//         console.error("User denied account access");
//       }
//     } else if (window.web3) {
//       App.web3Provider = window.web3.currentProvider;
//     } else {
//       App.web3Provider = new Web3.providers.HttpProvider('http://localhost:7545');
//     }
//     web3 = new Web3(App.web3Provider);

//     return App.initContract();
//   },

//   initContract: function() {
//     $.getJSON("Election.json", function(election) {
//       App.contracts.Election = TruffleContract(election);
//       App.contracts.Election.setProvider(App.web3Provider);

//       return App.render();
//     });
//   },

//   render: function() {
//     var electionInstance;
//     var loader = $("#loader");
//     var content = $("#content");

//     // Light color gradient background
//     $("body").css({
//       "background": "linear-gradient(135deg, #cfe2f3 0%, #D7E3D1 100%)", // Light pink to light blue gradient
//       "min-height": "100vh",
//       "display": "flex",
//       "align-items": "center",
//       "justify-content": "center",
//       "font-family": "Arial, sans-serif",
//       "color": "#333"
//     });

//     // Styling for loader
//     loader.css({
//       "text-align": "center",
//       "padding": "20px",
//       "background": "rgba(255, 255, 255, 0.1)",
//       "border-radius": "10px",
//       "color": "#fff",
//       "font-size": "18px"
//     });

//     // Enhanced content styling
//     content.css({
//       "background-color": "rgba(255, 255, 255, 0.9)",
//       "padding": "30px",
//       "border-radius": "12px",
//       "box-shadow": "0 8px 20px rgba(0, 0, 0, 0.2)",
//       "width": "100%",
//       "max-width": "700px",
//       "text-align": "center"
//     });

//     loader.show();
//     content.hide();

//     web3.eth.getCoinbase(function(err, account) {
//       if (err === null) {
//         App.account = account;
//         $("#accountAddress").html(`Your Account: ${account}`).css({
//           "font-weight": "bold",
//           "color": "#333",
//           "background-color": "#e0f7fa",
//           "padding": "10px 20px",
//           "border-radius": "12px",
//           "margin-bottom": "20px",
//           "text-align": "center",
//           "display": "inline-block"
//         });
//       }
//     });

//     App.contracts.Election.deployed().then(function(instance) {
//       electionInstance = instance;
//       return electionInstance.candidatesCount();
//     }).then(function(candidatesCount) {
//       var candidatesResults = $("#candidatesResults");
//       candidatesResults.empty();

//       let maxVoteCount = 0;
//       let winner = null;

//       for (var i = 1; i <= candidatesCount; i++) {
//         electionInstance.candidates(i).then(function(candidate) {
//           var id = candidate[0];
//           var name = candidate[1];
//           var voteCount = candidate[2];

//           if (voteCount > maxVoteCount) {
//             maxVoteCount = voteCount;
//             winner = name;
//           }

//           var candidateTemplate = `
//             <tr style="border-bottom: 1px solid #ddd;">
//               <th style="color: #007bff; font-size: 1.1em; padding: 8px 12px;">${id}</th>
//               <td style="padding: 8px 12px; color: #333;">${name}</td>
//               <td style="padding: 8px 12px; color: #666;">${voteCount}</td>
//               <td><button class='btn btn-primary' onclick='App.castVote(${id})' style='background-color: #28a745; border-color: #28a745; padding: 8px 16px; font-size: 0.9em; border-radius: 8px;'>Vote</button></td>
//             </tr>`;
//           candidatesResults.append(candidateTemplate);
//         });
//       }

//       $("#declareWinnerButton").click(function() {
//         if (winner) {
//           $("#winner").html(`Winner: ${winner} with ${maxVoteCount} votes`).css({
//             "color": "#28a745",
//             "font-weight": "bold",
//             "font-size": "1.2em",
//             "margin-top": "20px"
//           });
//         }
//       });

//       loader.hide();
//       content.show();
//     }).catch(function(error) {
//       console.warn(error);
//     });
//   },

//   castVote: function(candidateId) {
//     App.contracts.Election.deployed().then(function(instance) {
//       return instance.vote(candidateId, { from: App.account });
//     }).then(function(result) {
//       console.log("Vote cast successfully!");
//       App.listenForEvents();
//       App.render();
//     }).catch(function(err) {
//       console.error(err);
//     });
//   },

//   listenForEvents: function() {
//     App.contracts.Election.deployed().then(function(instance) {
//       instance.votedEvent({}, {
//         fromBlock: 0,
//         toBlock: 'latest'
//       }).watch(function(error, event) {
//         if (!error) {
//           console.log("Event triggered", event);
//           App.render();
//         } else {
//           console.error(error);
//         }
//       });
//     });
//   }
// };

// $(function() {
//   $(window).load(function() {
//     App.init();
//   });
// });

// // Enhanced Declare Winner button styling
// $(document).ready(function() {
//   $("#content").append(`
//     <div style="margin-top: 30px; text-align: center;">
//       <button id="declareWinnerButton" class="btn btn-success" style="padding: 12px 24px; font-size: 1em; background-color: #007bff; border-color: #007bff; border-radius: 10px; color: white;">Declare Winner</button>
//       <p id="winner" style="padding-top: 10px; font-size: 1.1em;"></p>
//     </div>
//   `);
// });




